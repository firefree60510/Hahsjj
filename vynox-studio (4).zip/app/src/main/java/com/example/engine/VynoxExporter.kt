package com.example.engine

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.util.Log
import androidx.annotation.OptIn
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.Presentation
import androidx.media3.effect.RgbFilter
import androidx.media3.effect.ScaleAndRotateTransformation
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.TransformationRequest
import androidx.media3.transformer.Transformer
import com.example.model.ExportFps
import com.example.model.ExportResolution
import com.example.model.ExportSettings
import com.example.model.FilterEffect
import com.example.model.VynoxProject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(UnstableApi::class)
class VynoxExporter(private val context: Context) {
    companion object {
        private const val TAG = "VynoxExporter"
    }

    sealed class ExportState {
        object Idle : ExportState()
        data class Progress(val percentage: Int, val description: String) : ExportState()
        data class Success(val outputUri: Uri, val filePath: String, val fileSizeMb: Float) : ExportState()
        data class Error(val message: String) : ExportState()
        object Cancelled : ExportState()
    }

    private var activeTransformer: Transformer? = null
    private var isCancelled = false
    private val progressHandler = Handler(Looper.getMainLooper())
    private val progressHolder = ProgressHolder()

    suspend fun exportProject(
        project: VynoxProject,
        settings: ExportSettings,
        onStateChanged: (ExportState) -> Unit
    ) = withContext(Dispatchers.Main) {
        if (project.videoClips.isEmpty()) {
            onStateChanged(ExportState.Error("Project has no media clips to export."))
            return@withContext
        }

        isCancelled = false
        onStateChanged(ExportState.Progress(0, "Preparing media composition..."))

        val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val cleanName = project.name.replace(Regex("[^a-zA-Z0-9_-]"), "_").ifEmpty { "Vynox" }
        val tempOutputFile = File(context.cacheDir, "${cleanName}_${timestamp}.mp4")

        try {
            // Build EditedMediaItems for each clip
            val editedMediaItems = mutableListOf<EditedMediaItem>()

            for (clip in project.videoClips) {
                val mediaItemBuilder = MediaItem.Builder()
                    .setUri(Uri.parse(clip.uri))

                // Apply trimming if valid range
                if (clip.trimEndMs > clip.trimStartMs && !clip.isImage) {
                    val clippingConfig = MediaItem.ClippingConfiguration.Builder()
                        .setStartPositionMs(clip.trimStartMs)
                        .setEndPositionMs(clip.trimEndMs)
                        .build()
                    mediaItemBuilder.setClippingConfiguration(clippingConfig)
                }

                val mediaItem = mediaItemBuilder.build()
                val videoEffects = mutableListOf<Effect>()

                // Canvas aspect ratio presentation
                videoEffects.add(
                    Presentation.createForAspectRatio(
                        project.aspectRatio.ratio,
                        Presentation.LAYOUT_SCALE_TO_FIT
                    )
                )

                // Rotation & Flip
                if (clip.rotationDegrees != 0 || clip.flipH || clip.flipV) {
                    val scaleX = if (clip.flipH) -1f else 1f
                    val scaleY = if (clip.flipV) -1f else 1f
                    videoEffects.add(
                        ScaleAndRotateTransformation.Builder()
                            .setRotationDegrees(clip.rotationDegrees.toFloat())
                            .setScale(scaleX, scaleY)
                            .build()
                    )
                }

                // Filter effects
                when (clip.filterEffect) {
                    FilterEffect.NOIR -> videoEffects.add(RgbFilter.createGrayscaleFilter())
                    FilterEffect.VINTAGE -> videoEffects.add(RgbFilter.createInvertedFilter())
                    else -> {}
                }

                val editedClip = EditedMediaItem.Builder(mediaItem)
                    .setEffects(Effects(emptyList(), videoEffects))
                    .setRemoveAudio(clip.volume <= 0f)
                    .apply {
                        if (clip.isImage) {
                            // Give image clip the duration configured by user
                            setDurationUs(clip.durationMs * 1000L)
                            setFrameRate(settings.frameRate.fps)
                        }
                    }
                    .build()

                editedMediaItems.add(editedClip)
            }

            val sequence = EditedMediaItemSequence(editedMediaItems)
            val composition = Composition.Builder(listOf(sequence)).build()

            // Transcode resolution & codec settings
            val targetHeight = when (settings.resolution) {
                ExportResolution.RES_480P -> 480
                ExportResolution.RES_720P -> 720
                ExportResolution.RES_1080P -> 1080
            }

            val transformerBuilder = Transformer.Builder(context)
                .setVideoMimeType(MimeTypes.VIDEO_H264)
                .setAudioMimeType(MimeTypes.AUDIO_AAC)
                .addListener(object : Transformer.Listener {
                    override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                        progressHandler.removeCallbacksAndMessages(null)
                        if (isCancelled) return

                        // Save final exported video to public Movies or internal storage
                        val finalUri = saveToPublicMovies(tempOutputFile, "${cleanName}_${timestamp}.mp4")
                        val sizeMb = tempOutputFile.length() / (1024f * 1024f)

                        Log.d(TAG, "Export completed successfully: ${tempOutputFile.absolutePath}")
                        onStateChanged(
                            ExportState.Success(
                                outputUri = finalUri,
                                filePath = tempOutputFile.absolutePath,
                                fileSizeMb = String.format(Locale.US, "%.2f", sizeMb).toFloat()
                            )
                        )
                    }

                    override fun onError(
                        composition: Composition,
                        exportResult: ExportResult,
                        exportException: ExportException
                    ) {
                        progressHandler.removeCallbacksAndMessages(null)
                        Log.e(TAG, "Export error: ${exportException.message}", exportException)
                        if (!isCancelled) {
                            onStateChanged(
                                ExportState.Error(
                                    exportException.message ?: "Video rendering failed. Please try a different resolution."
                                )
                            )
                        }
                    }
                })

            val transformer = transformerBuilder.build()
            activeTransformer = transformer

            // Start export
            transformer.start(composition, tempOutputFile.absolutePath)

            // Polling progress runnable
            val pollRunnable = object : Runnable {
                override fun run() {
                    if (isCancelled || activeTransformer == null) return
                    val state = transformer.getProgress(progressHolder)
                    if (state == Transformer.PROGRESS_STATE_AVAILABLE) {
                        val pct = progressHolder.progress.coerceIn(0, 100)
                        onStateChanged(ExportState.Progress(pct, "Rendering video timeline ($pct%)..."))
                    }
                    progressHandler.postDelayed(this, 300L)
                }
            }
            progressHandler.postDelayed(pollRunnable, 300L)

        } catch (e: Exception) {
            Log.e(TAG, "Export start exception: ${e.message}", e)
            onStateChanged(ExportState.Error(e.message ?: "Failed to start export engine."))
        }
    }

    fun cancelExport() {
        isCancelled = true
        progressHandler.removeCallbacksAndMessages(null)
        try {
            activeTransformer?.cancel()
        } catch (e: Exception) {
            Log.w(TAG, "Error cancelling transformer: ${e.message}")
        }
        activeTransformer = null
    }

    private fun saveToPublicMovies(sourceFile: File, displayName: String): Uri {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val values = ContentValues().apply {
                    put(MediaStore.Video.Media.DISPLAY_NAME, displayName)
                    put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                    put(MediaStore.Video.Media.RELATIVE_PATH, "${Environment.DIRECTORY_MOVIES}/VynoxStudio")
                }
                val resolver = context.contentResolver
                val uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                if (uri != null) {
                    resolver.openOutputStream(uri)?.use { out ->
                        FileInputStream(sourceFile).use { input ->
                            input.copyTo(out)
                        }
                    }
                    return uri
                }
            }
            Uri.fromFile(sourceFile)
        } catch (e: Exception) {
            Log.w(TAG, "Could not write to MediaStore, returning cached file uri: ${e.message}")
            Uri.fromFile(sourceFile)
        }
    }
}

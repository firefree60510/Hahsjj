package com.example.model

import java.util.UUID

data class ColorAdjustments(
    val brightness: Float = 0f,      // -1f to 1f
    val contrast: Float = 1f,        // 0.5f to 2f
    val saturation: Float = 1f,      // 0f to 2f
    val temperature: Float = 0f,     // -1f to 1f (cool to warm)
    val tint: Float = 0f,            // -1f to 1f (green to magenta)
    val vignette: Float = 0f         // 0f to 1f
)

data class VideoClip(
    val id: String = UUID.randomUUID().toString(),
    val uri: String,
    val name: String = "Clip",
    val isImage: Boolean = false,
    val sourceDurationMs: Long = 5000L,
    val trimStartMs: Long = 0L,
    val trimEndMs: Long = 5000L,
    val speed: Float = 1.0f,
    val volume: Float = 1.0f,
    val rotationDegrees: Int = 0,
    val flipH: Boolean = false,
    val flipV: Boolean = false,
    val filterEffect: FilterEffect = FilterEffect.NONE,
    val opacity: Float = 1.0f,
    val chromaKeyEnabled: Boolean = false,
    val chromaKeyColorHex: Long = 0xFF00FF00
) {
    val durationMs: Long
        get() {
            val rawTrim = (trimEndMs - trimStartMs).coerceAtLeast(100L)
            return (rawTrim / speed.coerceAtLeast(0.1f)).toLong()
        }
}

data class AudioClip(
    val id: String = UUID.randomUUID().toString(),
    val uri: String,
    val title: String = "Audio Track",
    val startTimelineMs: Long = 0L,
    val trimStartMs: Long = 0L,
    val durationMs: Long = 5000L,
    val volume: Float = 1.0f,
    val fadeInMs: Long = 0L,
    val fadeOutMs: Long = 0L,
    val isVoiceOver: Boolean = false
)

data class TextOverlay(
    val id: String = UUID.randomUUID().toString(),
    val text: String = "Sample Text",
    val fontSizeSp: Float = 24f,
    val textColorHex: Long = 0xFFFFFFFF,
    val outlineColorHex: Long = 0xFF000000,
    val bgColorHex: Long = 0x00000000,
    val hasBackground: Boolean = false,
    val hasOutline: Boolean = true,
    val fontFamilyName: String = "Default",
    val xPercent: Float = 0.5f,
    val yPercent: Float = 0.5f,
    val startTimelineMs: Long = 0L,
    val endTimelineMs: Long = 4000L,
    val animation: TextAnimation = TextAnimation.NONE
)

data class ImageOverlay(
    val id: String = UUID.randomUUID().toString(),
    val uri: String,
    val xPercent: Float = 0.5f,
    val yPercent: Float = 0.5f,
    val scale: Float = 1.0f,
    val rotation: Float = 0f,
    val opacity: Float = 1.0f,
    val startTimelineMs: Long = 0L,
    val endTimelineMs: Long = 4000L
)

data class ClipTransition(
    val clipIndex: Int,
    val type: TransitionType = TransitionType.NONE,
    val durationMs: Long = 500L
)

data class ExportSettings(
    val resolution: ExportResolution = ExportResolution.RES_1080P,
    val frameRate: ExportFps = ExportFps.FPS_30,
    val quality: ExportQuality = ExportQuality.HIGH
)

enum class ExportResolution(val label: String, val width: Int, val height: Int) {
    RES_480P("480p (SD)", 854, 480),
    RES_720P("720p (HD)", 1280, 720),
    RES_1080P("1080p (Full HD)", 1920, 1080)
}

enum class ExportFps(val label: String, val fps: Int) {
    FPS_24("24 FPS (Cinematic)", 24),
    FPS_30("30 FPS (Standard)", 30),
    FPS_60("60 FPS (Smooth)", 60)
}

enum class ExportQuality(val label: String, val bitrateMultiplier: Float) {
    STANDARD("Standard (Fast)", 0.8f),
    HIGH("High Quality", 1.2f),
    ULTRA("Ultra (Crisp)", 1.8f)
}

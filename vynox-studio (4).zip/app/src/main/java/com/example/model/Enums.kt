package com.example.model

enum class AspectRatio(val label: String, val widthRatio: Float, val heightRatio: Float) {
    RATIO_9_16("9:16 Vertical", 9f, 16f),
    RATIO_16_9("16:9 Landscape", 16f, 9f),
    RATIO_1_1("1:1 Square", 1f, 1f),
    RATIO_4_5("4:5 Portrait", 4f, 5f);

    val ratio: Float get() = widthRatio / heightRatio
}

enum class CanvasFitMode {
    FIT, FILL
}

enum class FilterEffect(val displayName: String) {
    NONE("Normal"),
    VIBRANT("Vibrant"),
    CINEMATIC("Cinematic"),
    WARM("Warm Sunset"),
    COOL("Cool Ice"),
    NOIR("Noir B&W"),
    CYBERPUNK("Cyber Neon"),
    VINTAGE("Vintage 90s")
}

enum class TransitionType(val displayName: String) {
    NONE("None"),
    FADE("Fade"),
    DISSOLVE("Dissolve"),
    SLIDE_LEFT("Slide Left"),
    SLIDE_RIGHT("Slide Right"),
    ZOOM_IN("Zoom In"),
    WIPE("Wipe")
}

enum class TextAnimation(val displayName: String) {
    NONE("None"),
    FADE_IN("Fade In"),
    SLIDE_UP("Slide Up"),
    ZOOM("Zoom In"),
    POP("Pop")
}
